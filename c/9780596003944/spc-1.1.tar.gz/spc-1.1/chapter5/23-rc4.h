typedef struct {
  unsigned char sbox[256];
  unsigned char i, j;
} RC4_CTX;
