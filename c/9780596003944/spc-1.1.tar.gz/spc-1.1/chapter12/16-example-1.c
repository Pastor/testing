void my_func(void) {
  int x;

  NULLPAD_10;
  for (x = 0;  x < 10; x++) printf("%x\n", x);
}
