This is a simple standalone application example that uses libstlink.
You can use this as a boilerplate for your own app development
